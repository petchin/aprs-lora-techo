#include "hostlink.h"
#include <Arduino.h>
#include "ble_kiss.h"

bool hostLinkActive() {
  return (bool)Serial || bleConnected();
}
