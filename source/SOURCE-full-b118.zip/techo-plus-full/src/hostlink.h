// hostlink.h — detect a USB/BLE host that may act as an internet iGate.
#pragma once

// True when a USB CDC host is connected (DTR) or a BLE host is connected.
// Used by the "Digi only when no host" fallback. It is a proxy for "an iGate
// host is present"; the T-Echo itself has no internet access and cannot test
// the internet connection.
bool hostLinkActive();
