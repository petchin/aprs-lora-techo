# APRS-TH Full firmware — T-Echo / T-Echo Plus

เวอร์ชันเต็มสำหรับ **LilyGO T-Echo / T-Echo Plus (nRF52840 + SX1262 433 MHz)**
ต่อยอดจาก [F4LEK-TECHO-APRS](https://github.com/remy33140/F4LEK-TECHO-APRS)
ซึ่งเป็น fork ของ [EA2OY APRS System](https://github.com/EA2OY/EA2OY-APRS-SYSTEM) (GPL-3.0)

## สิ่งที่ปรับสำหรับ build นี้ (APRS-TH)

- `APP_NAME_STR` = **APRS-TH T-Echo Plus**
- default comment = `APRS-TH T-Echo Plus 433.775`
- default status = `APRS-TH`
- default TX power = **20 dBm** (เดิม 22 dBm) — ปรับได้ในเมนู/configurator
- แก้บั๊ก linker กับ GCC 15: `__isr_vector` ถูกประกาศใน anonymous namespace
  ทำให้ได้ symbol `(anonymous namespace)::__isr_vector` (undefined reference)
  — ย้าย declaration ออกมาเป็น global `extern "C"`
- ล็อก build number เป็น `b114` และปิดสคริปต์ auto-increment
  เพื่อให้ source/ไบนารีตรงกัน
- ค่าเริ่มต้นความถี่เป็น **433.775 MHz**, SF12, BW125, CR4/5 (มีอยู่ในต้นทางแล้ว)

## ฟีเจอร์

- Tracker + Smart Beaconing
- Digipeater (WIDE1-1 / WIDE2-n)
- APRS messaging + telemetry + weather (ถ้ามีเซนเซอร์ I2C)
- เมนูบนจอ e-paper 200×200
- BLE KISS + Web Configurator ผ่าน USB
- USB KISS/TNC2 bridge
- Low-power / battery management ของ T-Echo

> UI ของต้นทางเป็นภาษาสเปน/อังกฤษ — คู่มือภาษาไทยอยู่ที่หน้าเว็บ
> และตัว firmware ใช้ได้กับทั้ง T-Echo รุ่นปกติและ Plus (pinout เดียวกัน)

## Build

ต้องมี PlatformIO + ARM toolchain ที่รองรับ host ของคุณ

```bash
cd firmware/techo-plus-full
pio run -e techo_s140v7        # สำหรับ SoftDevice S140 v7 (ตรวจ INFO_UF2.TXT)
# หรือ pio run -e techo        # สำหรับ SoftDevice S140 v6.1.1
```

ผลลัพธ์: `.pio/build/techo_s140v7/firmware.uf2`

### หมายเหตุ toolchain บน Raspberry Pi (aarch64)

PlatformIO registry ไม่มี `toolchain-gccarmnoneeabi` สำหรับ aarch64
ให้ติดตั้ง xPack GNU Arm Embedded GCC (linux-arm64) แล้ววางเป็น package
`~/.platformio/packages/toolchain-gccarmnoneeabi` พร้อม `package.json` เวอร์ชัน `1.70201.0`
และใช้บรรทัดนี้ใน `platformio.ini`:

```ini
platform_packages = platformio/toolchain-gccarmnoneeabi@symlink:///home/<user>/.platformio/packages/toolchain-gccarmnoneeabi
```

## License

GPL-3.0 — ดู `LICENSE` และ `THIRD_PARTY.md`
