// ota.h — reboot into the Adafruit/nRF52 bootloader OTA (BLE DFU) mode.
#pragma once

// Sets GPREGRET to 0xA8 and resets. The bootloader then advertises the
// Nordic Secure DFU service over Bluetooth (no USB cable needed for the app).
void enterOtaDfu();
