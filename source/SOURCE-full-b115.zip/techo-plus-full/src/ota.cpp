// ota.cpp — enter BLE OTA (Nordic Secure DFU) mode on the next boot.
// 0xA8 is the Adafruit nRF52 bootloader magic for OTA (0x57 = UF2).
#include "ota.h"
#include <Arduino.h>
#include <nrf.h>

void enterOtaDfu() {
  NRF_POWER->GPREGRET = 0xA8;
  NVIC_SystemReset();
}
