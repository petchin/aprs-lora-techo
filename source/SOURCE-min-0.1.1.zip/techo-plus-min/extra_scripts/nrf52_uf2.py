#!/usr/bin/env python3
# Convert the PlatformIO application HEX to an Adafruit nRF52 UF2 (family 0xADA52840).
# Derived from F4LEK-TECHO-APRS extra_scripts/nrf52_uf2.py (GPL-3.0).
Import("env")
import sys
from os.path import basename

BOOTLOADER_BASE = 0xEA000


def hex_highest_addr(path):
    highest = 0
    base = 0
    with open(path, "r") as fh:
        for line in fh:
            line = line.strip()
            if not line.startswith(":"):
                continue
            count = int(line[1:3], 16)
            addr = int(line[3:7], 16)
            rectype = int(line[7:9], 16)
            if rectype == 2:
                base = int(line[9:13], 16) << 4
            elif rectype == 4:
                base = int(line[9:13], 16) << 16
            elif rectype == 0 and count > 0:
                highest = max(highest, base + addr + count)
    return highest


def nrf52_hex_to_uf2(source, target, env):
    hex_path = target[0].get_abspath()
    uf2_path = hex_path.replace(".hex", ".uf2")
    top = hex_highest_addr(hex_path)
    if top > BOOTLOADER_BASE:
        sys.stderr.write("\n*** BUILD STOPPED: app over the bootloader at 0x%X\n" % BOOTLOADER_BASE)
        env.Exit(1)
    print("Flash map: app ends at 0x%X, bootloader at 0x%X (%.1f KB free)"
          % (top, BOOTLOADER_BASE, (BOOTLOADER_BASE - top) / 1024.0))
    env.Execute(env.VerboseAction(
        '"%s" "$PROJECT_DIR/bin/uf2conv.py" "%s" -c -f 0xADA52840 -o "%s"'
        % (sys.executable, hex_path, uf2_path),
        "Generating UF2 from %s" % basename(hex_path)))


env.AddPostAction("$BUILD_DIR/${PROGNAME}.hex", nrf52_hex_to_uf2)
