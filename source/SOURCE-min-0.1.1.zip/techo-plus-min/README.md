# APRS-TH minimal firmware — LilyGO T-Echo Plus

พอร์ตแกน APRS LoRa จาก [nakhonthai/ESP32APRS_LoRa](https://github.com/nakhonthai/ESP32APRS_LoRa)
มาลง **nRF52840 + SX1262 433 MHz** (T-Echo / T-Echo Plus)

> สถานะ: **v0.1.0 experimental** — คอมไพล์ผ่านและใช้ pinout ทางการของ LilyGO
> แต่ยังไม่ได้ทดสอบกับบอร์ดจริง ควร backup firmware เดิมก่อนแฟลช

## ทำอะไรได้

- **Tracker**: ส่ง APRS position ผ่าน LoRa 433.775 MHz SF12 BW125 CR4/5
  - Smart-ish beacon: ระยะห่างตามความเร็ว (moving / stationary interval)
  - ใส่ course/speed และ altitude (`/A=`) ใน packet
- **Digipeater**: WIDE1-1 พร้อม duplicate cache 30 วินาที
- **USB KISS TNC**: แปลง LoRa TNC2 ↔ AX.25 ให้ aprx / APRSdroid ใช้เป็น TNC
  - `set usb kiss` (ค่าเริ่มต้น), `set usb tnc2`, `set usb off`
- **USB console**: ตั้งค่า callsign, path, comment, symbol, ความถี่, SF/BW/CR, กำลังส่ง,
  interval, mode และดูสถานะ
- **E-paper 200×200**: แสดง callsign, GPS, ระยะ/ความเร็ว, TX/RX, RSSI/SNR, แบตเตอรี่
- **ปุ่มผู้ใช้**: กดสั้น = ส่ง beacon ทันที

สิ่งที่ **ไม่มี** โดยเจตนา: WiFi iGate, WebServer, WireGuard, BLE — nRF52840 ไม่มี WiFi
และเพื่อให้ firmware เล็ก/เริ่มง่าย (BLE KISS อยู่ในเวอร์ชัน Full)

## Build

ต้องมี PlatformIO Core และ toolchain `arm-none-eabi-gcc` สำหรับ host ของคุณ

```bash
cd firmware/techo-plus-min
pio run -e techo_plus
# ได้ไฟล์ .pio/build/techo_plus/firmware.uf2
```

ถ้าใช้ Raspberry Pi (aarch64) ให้ติดตั้ง toolchain native แล้วชี้ `platform_packages`
ตามที่ระบุใน `platformio.ini` (หรือแก้ path ให้ตรงเครื่องคุณ)

## Flash

1. กด Reset 2 ครั้งติดกัน → ไดรฟ์ `TECHO` ขึ้น
2. ลาก `firmware.uf2` ลงไดรฟ์
3. เปิด serial 115200 baud

## คำสั่ง

```
help
info
set call E23BMY-12
set path WIDE1-1
set comment LoRa APRS Thailand
set symbol />
set freq 433.775
set sf 12
set bw 125
set cr 5
set power 20
set interval 120
set slow 600
set mode tracker|digi|kiss|off
set digi on|off
set usb kiss|tnc2|off
tx
save / reset / reboot
```

`set` จะบันทึกอัตโนมัติลง internal flash (`/aprs.json`)
ค่าที่เกี่ยวกับ radio (freq/sf/bw/cr/power) ต้อง `reboot` เพื่อเริ่ม radio ใหม่

## ต่อกับ aprx (iGate)

ใน `.env` ของโปรเจกต์ aprx ด้านบน:

```env
TNC_MODE=serial
TNC_DEVICE=/dev/ttyACM0
TNC_BAUD=115200
TX_OK=true
```

และเพิ่ม device ใน `docker-compose.yml`:

```yaml
devices:
  - /dev/ttyACM0:/dev/ttyACM0
```

ตั้ง firmware: `set mode kiss`, `set usb kiss`

## Pinout (T-Echo / T-Echo Plus)

| ส่วน | GPIO |
|---|---|
| SX1262 SCK/MOSI/MISO/CS | P0.19 / P0.22 / P0.23 / P0.24 |
| SX1262 RST/BUSY/DIO1/DIO3 | P0.25 / P0.17 / P0.20 / P0.21 |
| E-Paper SCK/MOSI/CS/DC | P0.31 / P0.29 / P0.30 / P0.28 |
| E-Paper RST/BUSY/PWR | P0.02 / P0.03 / P1.11 |
| GPS RX/TX (Serial1) | P1.09 / P1.08 @ 9600 |
| Battery ADC | P0.04 (1:2 divider) |
| Button / Buzzer | P1.10 / P0.06 |

## License

GPL-3.0. Portions:
- APRS/AX.25 concepts and the original ESP32 firmware: nakhonthai/ESP32APRS_LoRa
- Board variant/linker/UF2 packaging and SSD1681 init: F4LEK-TECHO-APRS (GPL-3.0)
- 5×7 font: F4LEK-TECHO-APRS (GPL-3.0)
- Pin map: LilyGO T-Echo, cfr34k/t-echo-lora-aprs, Meshtastic
