// ax25.cpp — AX.25 UI frame encode/decode (KISS bridge only; LoRa APRS itself
// carries TNC2 text, not AX.25).
#include "ax25.h"
#include <string.h>
#include <ctype.h>
#include <stdio.h>

bool ax25ParseCall(const char *text, char *base, size_t baseSize, uint8_t &ssid) {
  if (!text || !*text) return false;
  const char *dash = strchr(text, '-');
  size_t n = dash ? (size_t)(dash - text) : strlen(text);
  if (n == 0 || n > 6 || n >= baseSize) return false;
  ssid = 0;
  if (dash) {
    if (!dash[1]) return false;
    for (const char *p = dash + 1; *p; ++p) {
      if (!isdigit((unsigned char)*p)) return false;
      ssid = ssid * 10 + (*p - '0');
    }
    if (ssid > 15) return false;
  }
  for (size_t i = 0; i < n; ++i) {
    if (!isalnum((unsigned char)text[i])) return false;
    base[i] = (char)toupper((unsigned char)text[i]);
  }
  base[n] = '\0';
  return true;
}

void ax25FormatCall(const char *base, uint8_t ssid, char *out, size_t outSize) {
  if (ssid) snprintf(out, outSize, "%s-%u", base, ssid);
  else      snprintf(out, outSize, "%s", base);
}

static uint16_t crcX25(const uint8_t *data, size_t len) {
  uint16_t crc = 0xFFFF;
  for (size_t i = 0; i < len; ++i) {
    crc ^= data[i];
    for (uint8_t b = 0; b < 8; ++b)
      crc = (crc & 1) ? ((crc >> 1) ^ 0x8408) : (crc >> 1);
  }
  return crc ^ 0xFFFF;
}

static bool putAddress(uint8_t *out, size_t maxLen, size_t &pos,
                       const char *text, bool last, bool repeated) {
  char base[7];
  uint8_t ssid;
  if (!ax25ParseCall(text, base, sizeof(base), ssid)) return false;
  if (pos + 7 > maxLen) return false;
  memset(out + pos, ' ' << 1, 6);
  for (size_t i = 0; i < strlen(base) && i < 6; ++i)
    out[pos + i] = (uint8_t)(base[i] << 1);
  uint8_t ssidByte = 0x60 | ((ssid & 0x0F) << 1);
  if (last) ssidByte |= 0x01;
  if (repeated) ssidByte |= 0x80;
  out[pos + 6] = ssidByte;
  pos += 7;
  return true;
}

size_t ax25Encode(const Ax25Frame &f, uint8_t *out, size_t maxLen) {
  size_t pos = 0;
  if (!putAddress(out, maxLen, pos, f.dst, f.pathCount == 0, false)) return 0;
  if (!putAddress(out, maxLen, pos, f.src, f.pathCount == 0, false)) return 0;
  for (uint8_t i = 0; i < f.pathCount; ++i)
    if (!putAddress(out, maxLen, pos, f.path[i], i + 1 == f.pathCount, f.repeated[i]))
      return 0;

  if (pos + 2 + f.infoLen + 2 > maxLen) return 0;
  out[pos++] = 0x03;  // UI
  out[pos++] = 0xF0;  // no layer 3
  memcpy(out + pos, f.info, f.infoLen);
  pos += f.infoLen;
  uint16_t crc = crcX25(out, pos);
  out[pos++] = (uint8_t)(crc & 0xFF);
  out[pos++] = (uint8_t)(crc >> 8);
  return pos;
}

static bool getAddress(const uint8_t *in, size_t len, size_t &pos,
                       char *out, size_t outSize, bool &last, bool &repeated) {
  if (pos + 7 > len) return false;
  char base[7];
  size_t n = 0;
  for (int i = 0; i < 6; ++i) {
    char c = (char)(in[pos + i] >> 1);
    if (c != ' ' && n < 6) base[n++] = c;
  }
  base[n] = '\0';
  uint8_t ssidByte = in[pos + 6];
  uint8_t ssid = (ssidByte >> 1) & 0x0F;
  last = ssidByte & 0x01;
  repeated = ssidByte & 0x80;
  ax25FormatCall(base, ssid, out, outSize);
  pos += 7;
  return true;
}

bool ax25Decode(const uint8_t *in, size_t len, Ax25Frame &f) {
  if (len < 18 || len > 330) return false;
  f.pathCount = 0;
  f.infoLen = 0;
  size_t pos = 0;
  bool last = false, rep = false;

  if (!getAddress(in, len, pos, f.dst, sizeof(f.dst), last, rep)) return false;
  if (!getAddress(in, len, pos, f.src, sizeof(f.src), last, rep)) return false;
  while (!last) {
    if (f.pathCount >= 8) return false;
    if (!getAddress(in, len, pos, f.path[f.pathCount], sizeof(f.path[0]), last, rep))
      return false;
    f.repeated[f.pathCount] = rep;
    ++f.pathCount;
  }

  if (pos + 2 > len) return false;
  if (in[pos] != 0x03 || in[pos + 1] != 0xF0) return false;
  pos += 2;

  if (pos + 2 > len) return false;
  uint16_t got = (uint16_t)in[len - 2] | ((uint16_t)in[len - 1] << 8);
  uint16_t want = crcX25(in, len - 2);
  if (got != want) return false;

  size_t n = len - 2 - pos;
  if (n > sizeof(f.info)) return false;
  memcpy(f.info, in + pos, n);
  f.infoLen = (uint16_t)n;
  return true;
}
