// ui.cpp — status layout for the T-Echo Plus e-paper.
#include "ui.h"
#include "epd.h"
#include "cfg.h"
#include "gps.h"
#include "radio.h"
#include <stdio.h>
#include <math.h>

void uiInit() { epdInit(); }

void uiDraw(const UiState &st) {
  char line[48];
  epdClear();

  epdText(4, 2, "APRS-TH  T-Echo Plus", 1);
  epdLine(13);

  epdText(4, 20, g_cfg.callsign, 2);

  if (gpsHasFix()) {
    snprintf(line, sizeof(line), "GPS FIX  %usat", gpsSats());
  } else {
    snprintf(line, sizeof(line), "GPS NO FIX  %usat", gpsSats());
  }
  epdText(4, 42, line, 1);

  snprintf(line, sizeof(line), "%.5f%c", fabs(gpsLat()), gpsLat() < 0 ? 'S' : 'N');
  epdText(4, 54, line, 1);
  snprintf(line, sizeof(line), "%.5f%c", fabs(gpsLon()), gpsLon() < 0 ? 'W' : 'E');
  epdText(4, 66, line, 1);

  snprintf(line, sizeof(line), "%.0fkm/h  crs %.0f", gpsSpeedKmh(), gpsCourseDeg());
  epdText(4, 78, line, 1);
  if (isfinite(gpsAltM())) snprintf(line, sizeof(line), "alt %.0fm  hdop %.1f", gpsAltM(), gpsHdop());
  else                     snprintf(line, sizeof(line), "alt --   hdop %.1f", gpsHdop());
  epdText(4, 90, line, 1);

  epdLine(102);
  snprintf(line, sizeof(line), "TX %lu   RX %lu", (unsigned long)st.txCount, (unsigned long)st.rxCount);
  epdText(4, 108, line, 1);
  snprintf(line, sizeof(line), "RSSI %.0f  SNR %.0f", st.lastRssi, st.lastSnr);
  epdText(4, 120, line, 1);
  snprintf(line, sizeof(line), "LAST %s", st.lastRx[0] ? st.lastRx : "-");
  epdText(4, 132, line, 1);

  epdLine(144);
  snprintf(line, sizeof(line), "BAT %u.%02uV", st.batteryMv / 1000, (st.batteryMv % 1000) / 10);
  epdText(4, 150, line, 1);
  const char *mode = g_cfg.mode == MODE_TRACKER ? "tracker" :
                     g_cfg.mode == MODE_DIGI ? "digi" :
                     g_cfg.mode == MODE_KISS ? "kiss" : "off";
  snprintf(line, sizeof(line), "%s %s", mode, g_cfg.digiEnabled ? "+digi" : "");
  epdText(4, 162, line, 1);
  snprintf(line, sizeof(line), "%.3f SF%u", g_cfg.freqHz / 1000000.0, g_cfg.sf);
  epdText(4, 174, line, 1);
  snprintf(line, sizeof(line), "UP %luh%02lum  USB %s",
           (unsigned long)(st.uptimeSec / 3600), (unsigned long)((st.uptimeSec / 60) % 60),
           g_cfg.usbMode == USB_KISS ? "KISS" : g_cfg.usbMode == USB_TNC2 ? "TNC2" : "off");
  epdText(4, 186, line, 1);

  epdRefresh();
}
