// epd.h — compact bit-banged SSD1681 (GDEH0154D67) 200x200 driver.
// The T-Echo panel is on its own pins (P0.31/P0.29), not the radio SPI bus.
#pragma once

#include <Arduino.h>

void epdInit();
void epdClear();
void epdPixel(int16_t x, int16_t y, bool black);
void epdText(int16_t x, int16_t y, const char *text, uint8_t scale = 1, bool black = true);
void epdLine(int16_t y);
void epdRefresh();
void epdSleep();
int16_t epdTextWidth(const char *text, uint8_t scale = 1);
