// ax25.h — minimal AX.25 UI frame codec used by the USB KISS TNC bridge.
#pragma once

#include <Arduino.h>

struct Ax25Frame {
  char     dst[12];
  char     src[12];
  char     path[8][12];
  bool     repeated[8];
  uint8_t  pathCount;
  uint8_t  info[256];
  uint16_t infoLen;
};

size_t ax25Encode(const Ax25Frame &f, uint8_t *out, size_t maxLen);
bool   ax25Decode(const uint8_t *in, size_t len, Ax25Frame &f);

// "E23BMY-12" -> base "E23BMY", ssid 7. Returns false on bad input.
bool ax25ParseCall(const char *text, char *base, size_t baseSize, uint8_t &ssid);
void ax25FormatCall(const char *base, uint8_t ssid, char *out, size_t outSize);
