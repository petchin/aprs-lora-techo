// radio.h — SX1262 LoRa APRS physical layer.
#pragma once

#include <Arduino.h>
#include "cfg.h"

bool radioBegin(const Config &cfg);
void radioStartRx();
int16_t radioSendAprs(const char *tnc2, size_t len);
int16_t radioPoll(uint8_t *out, size_t maxLen, size_t *outLen, float *rssi, float *snr);
void radioIdle();
bool radioReady();
const char *radioLastErrorText();
int16_t radioLastError();
