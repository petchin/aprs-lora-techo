// kiss.h — KISS framing over the USB CDC port for the host TNC bridge.
#pragma once

#include <Arduino.h>

// Implemented in main.cpp: an AX.25 frame arrived from the host.
void appHandleHostAx25(const uint8_t *frame, size_t len);

void kissReset();
bool kissFeed(uint8_t b);           // true = byte consumed by the KISS decoder
void kissSendAx25(const uint8_t *frame, size_t len);
bool kissActive();
