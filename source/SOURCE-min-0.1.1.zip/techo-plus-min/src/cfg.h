// cfg.h — configuration for the APRS-TH T-Echo Plus port.
// Stored as JSON in the internal flash (Adafruit LittleFS / InternalFS).
#pragma once

#include <Arduino.h>

enum : uint8_t {
  MODE_TRACKER = 0,
  MODE_DIGI    = 1,
  MODE_KISS    = 2,   // host-driven (no own beacons)
  MODE_OFF     = 3,
};

enum : uint8_t {
  USB_OFF  = 0,
  USB_TNC2 = 1,
  USB_KISS = 2,
};

struct Config {
  char     callsign[12]   = "E23BMY-12";
  char     path[40]       = "WIDE1-1";
  char     comment[48]    = "LoRa APRS T-Echo Plus TH";
  char     symbolTable    = '/';
  char     symbol         = '>';
  uint32_t freqHz         = 433775000UL;
  uint8_t  sf             = 12;
  float    bwKhz          = 125.0f;
  uint8_t  cr             = 5;
  int8_t   powerDbm       = 20;
  uint16_t beaconSec      = 120;   // moving / normal interval
  uint16_t slowSec        = 600;   // stationary interval
  uint8_t  mode           = MODE_TRACKER;
  bool     digiEnabled    = true;
  uint8_t  usbMode        = USB_KISS;
  bool     gpsEco         = false; // power GPS only when needed (not implemented yet)
};

extern Config g_cfg;

void cfgLoad();
void cfgSave();
void cfgDefaults();
bool cfgSetCallsign(const char *value);
bool cfgSetSymbol(const char *value);   // two chars: table + symbol
void cfgPrint(Print &out);
