// ui.h — status screen on the 200x200 e-paper display.
#pragma once

#include <Arduino.h>

struct UiState {
  uint32_t txCount;
  uint32_t rxCount;
  float    lastRssi;
  float    lastSnr;
  char     lastRx[24];
  uint16_t batteryMv;
  uint32_t uptimeSec;
};

void uiInit();
void uiDraw(const UiState &st);
