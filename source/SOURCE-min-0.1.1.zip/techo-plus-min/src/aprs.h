// aprs.h — TNC2 text <-> AX.25 helpers and the APRS position beacon.
#pragma once

#include <Arduino.h>
#include "cfg.h"
#include "ax25.h"

struct Tnc2Packet {
  char     src[12];
  char     dst[12];
  char     path[8][12];
  bool     repeated[8];
  uint8_t  pathCount;
  char     info[256];
  uint16_t infoLen;
};

bool tnc2Parse(const char *line, Tnc2Packet &p);
bool tnc2ToAx25(const Tnc2Packet &p, Ax25Frame &f);
size_t tnc2FromAx25(const Ax25Frame &f, char *out, size_t maxLen);
size_t tnc2Build(const Tnc2Packet &p, char *out, size_t maxLen);

size_t aprsBuildPosition(const Config &cfg, double lat, double lon,
                         float speedKmh, float courseDeg, float altM,
                         char *out, size_t maxLen);
