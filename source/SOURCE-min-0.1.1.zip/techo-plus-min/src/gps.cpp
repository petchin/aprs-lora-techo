// gps.cpp — TinyGPSPlus on Serial1 (P1.09 RX / P1.08 TX, 9600 baud).
#include "gps.h"
#include "pins.h"
#include <TinyGPSPlus.h>

static TinyGPSPlus s_gps;
static uint32_t s_chars = 0;
static uint32_t s_lastFixMs = 0;

void gpsBegin() {
  Serial1.begin(GPS_BAUD);
}

void gpsPoll() {
  while (Serial1.available()) {
    char c = (char)Serial1.read();
    s_gps.encode(c);
    ++s_chars;
  }
  if (s_gps.location.isValid() && s_gps.location.age() < 5000)
    s_lastFixMs = millis();
}

bool gpsHasFix() {
  return s_gps.location.isValid() && s_gps.location.age() < 15000;
}

double gpsLat() { return s_gps.location.lat(); }
double gpsLon() { return s_gps.location.lng(); }
float  gpsSpeedKmh() { return s_gps.speed.isValid() ? (float)s_gps.speed.kmph() : 0.0f; }
float  gpsCourseDeg() { return s_gps.course.isValid() ? (float)s_gps.course.deg() : 0.0f; }
float  gpsAltM() { return s_gps.altitude.isValid() ? (float)s_gps.altitude.meters() : NAN; }
uint8_t gpsSats() { return (uint8_t)s_gps.satellites.value(); }
float gpsHdop() { return s_gps.hdop.isValid() ? (float)s_gps.hdop.hdop() : 99.9f; }
uint32_t gpsLastFixMs() { return s_lastFixMs; }
uint32_t gpsChars() { return s_chars; }
