// pins.h — LilyGO T-Echo / T-Echo Plus (nRF52840 + SX1262)
// Pin map from F4LEK-TECHO-APRS src/pins_techo.h (GPL-3.0),
// which in turn documents cfr34k/t-echo-lora-aprs + LilyGO + Meshtastic.
#pragma once

// ---- SX1262 (SPI0) ----
#define PIN_LORA_SCK   19   // P0.19
#define PIN_LORA_MOSI  22   // P0.22
#define PIN_LORA_MISO  23   // P0.23
#define PIN_LORA_CS    24   // P0.24
#define PIN_LORA_RST   25   // P0.25
#define PIN_LORA_BUSY  17   // P0.17
#define PIN_LORA_DIO1  20   // P0.20
#define PIN_LORA_DIO3  21   // P0.21 TCXO supply
#define LORA_TCXO_VOLTAGE 1.8f

// ---- e-paper GDEH0154D67 / SSD1681 200x200 (SPI1) ----
#define PIN_EPD_SCK    31   // P0.31
#define PIN_EPD_MOSI   29   // P0.29
#define PIN_EPD_MISO   38   // P1.06 (not really used by the panel)
#define PIN_EPD_CS     30   // P0.30
#define PIN_EPD_DC     28   // P0.28
#define PIN_EPD_RST    2    // P0.02
#define PIN_EPD_BUSY   3    // P0.03
#define PIN_EPD_PWR    43   // P1.11 panel power / backlight

// ---- power ----
#ifndef PIN_PWR_EN
#define PIN_PWR_EN     12   // P0.12 MOSFET: display, GPS, flash, LEDs, sensors
#endif
#ifndef PIN_REG_EN
#define PIN_REG_EN     13   // P0.13 3V3 regulator (LoRa module)
#endif

// ---- GPS L76K on Serial1 ----
#define PIN_GPS_RX     41   // P1.09 (MCU RX <- GPS TX)
#define PIN_GPS_TX     40   // P1.08 (MCU TX -> GPS RX)
#define GPS_BAUD       9600

// ---- battery / buttons / LEDs ----
#define PIN_BATTERY    4    // P0.04 AIN2, 1:2 divider
#define PIN_BUTTON     42   // P1.10 active low
#define PIN_LED_GREEN  33   // P1.01
#define PIN_LED_RED    35   // P1.03
#define PIN_LED_BLUE   14   // P0.14

// ---- T-Echo Plus extras ----
#define PIN_BUZZER     6    // P0.06
#define PIN_DRV_EN     8    // P0.08 haptic driver enable
