// main.cpp — APRS-TH minimal firmware for LilyGO T-Echo Plus.
//
// Port of the core ideas of nakhonthai/ESP32APRS_LoRa (GPL-3.0) to the
// nRF52840 + SX1262 T-Echo Plus. The ESP32-only parts (WiFi iGate, WebServer,
// WireGuard, weather/sensor web UI) are intentionally not ported: this MCU has
// no WiFi. This build provides tracker + WIDE1-1 digipeater + USB KISS/TNC2
// bridge, which is what the aprx container in ../../ expects.
#include <Arduino.h>
#include <RadioLib.h>
#include <nrf.h>
#include <string.h>
#include <stdio.h>
#include <math.h>

#include "pins.h"
#include "cfg.h"
#include "gps.h"
#include "radio.h"
#include "aprs.h"
#include "kiss.h"
#include "cli.h"
#include "ui.h"
#include "epd.h"

#ifndef APP_NAME
#define APP_NAME "APRS-TH T-Echo Plus"
#endif
#ifndef APP_VERSION
#define APP_VERSION "0.1.0"
#endif

static uint32_t s_txCount = 0;
static uint32_t s_rxCount = 0;
static float    s_lastRssi = 0;
static float    s_lastSnr = 0;
static char     s_lastRx[24] = "";
static uint16_t s_batteryMv = 0;
static uint32_t s_lastTxMs = 0;
static uint32_t s_lastDisplayMs = 0;
static uint32_t s_lastBatteryMs = 0;
static bool     s_beaconRequested = false;

static uint32_t s_dupHash[8] = {0};
static uint32_t s_dupMs[8] = {0};
static uint8_t  s_dupIdx = 0;

struct PendingFrame {
  bool     active;
  uint32_t atMs;
  char     tnc2[300];
};
static PendingFrame s_pending;

// ---------------------------------------------------------------- helpers --

static uint32_t hashFrame(const uint8_t *data, size_t len) {
  uint32_t h = 2166136261u;
  for (size_t i = 0; i < len; ++i) { h ^= data[i]; h *= 16777619u; }
  return h;
}

static bool seenRecently(uint32_t hash, uint32_t now) {
  for (uint8_t i = 0; i < 8; ++i) {
    if (s_dupHash[i] == hash && (now - s_dupMs[i]) < 30000) return true;
  }
  s_dupHash[s_dupIdx] = hash;
  s_dupMs[s_dupIdx] = now;
  s_dupIdx = (s_dupIdx + 1) % 8;
  return false;
}

static void ledPulse(uint8_t pin, uint16_t ms) {
  digitalWrite(pin, HIGH);
  delay(ms);
  digitalWrite(pin, LOW);
}

static void readBattery() {
  analogReference(AR_INTERNAL_3_0);
  analogReadResolution(12);
  analogSampleTime(40);
  uint32_t sum = 0;
  for (uint8_t i = 0; i < 8; ++i) sum += analogRead(PIN_BATTERY);
  analogSampleTime(3);
  analogReadResolution(10);
  float mv = (float)sum / 8.0f / 4095.0f * 3000.0f * 2.0f;
  s_batteryMv = (mv >= 2400.0f && mv <= 4500.0f) ? (uint16_t)(mv + 0.5f) : 0;
}

static void printLine(const char *text) {
  if (g_cfg.usbMode != USB_KISS) Serial.println(text);
}

// --------------------------------------------------------------- transmit --

static bool sendTnc2(const char *tnc2, const char *why) {
  size_t len = strlen(tnc2);
  int16_t st = radioSendAprs(tnc2, len);
  if (st == RADIOLIB_ERR_NONE) {
    ++s_txCount;
    s_lastTxMs = millis();
    ledPulse(PIN_LED_GREEN, 40);
    if (g_cfg.usbMode != USB_KISS) Serial.printf("TX(%s) %s\n", why, tnc2);
    return true;
  }
  if (g_cfg.usbMode != USB_KISS) Serial.printf("TX(%s) ERR %d\n", why, (int)st);
  ledPulse(PIN_LED_RED, 60);
  return false;
}

bool appSendPosition() {
  if (!gpsHasFix()) {
    Serial.println(F("TX skipped: no GPS fix"));
    return false;
  }
  char line[300];
  size_t n = aprsBuildPosition(g_cfg, gpsLat(), gpsLon(), gpsSpeedKmh(),
                               gpsCourseDeg(), gpsAltM(), line, sizeof(line));
  if (!n) return false;
  return sendTnc2(line, "pos");
}

void appRequestBeacon() { s_beaconRequested = true; }
void appReboot() { NVIC_SystemReset(); }

// ------------------------------------------------------------------ status --

void appPrintStatus(Print &out) {
  cfgPrint(out);
  out.printf("gps        fix=%d sats=%u lat=%.6f lon=%.6f\n",
             gpsHasFix() ? 1 : 0, gpsSats(), gpsLat(), gpsLon());
  out.printf("radio      %s", radioReady() ? "ready" : "ERROR");
  if (!radioReady()) out.printf(" (%s)", radioLastErrorText());
  out.println();
  out.printf("counters   tx=%lu rx=%lu\n", (unsigned long)s_txCount, (unsigned long)s_rxCount);
  out.printf("last rx    %s  rssi=%.0f snr=%.0f\n", s_lastRx[0] ? s_lastRx : "-", s_lastRssi, s_lastSnr);
  out.printf("battery    %u mV\n", s_batteryMv);
  out.printf("uptime     %lu s\n", (unsigned long)(millis() / 1000));
}

// ------------------------------------------------------------------- RX/TX --

static bool pathIsWide1(const Tnc2Packet &p, uint8_t &index) {
  for (uint8_t i = 0; i < p.pathCount; ++i) {
    if (p.repeated[i]) continue;
    if (!strcasecmp(p.path[i], "WIDE1-1")) { index = i; return true; }
  }
  return false;
}

static void maybeDigipeat(const Tnc2Packet &p, const uint8_t *raw, size_t rawLen) {
  if (!g_cfg.digiEnabled) return;
  if (!strcasecmp(p.src, g_cfg.callsign)) return;

  uint8_t idx;
  if (!pathIsWide1(p, idx)) return;
  if (seenRecently(hashFrame(raw, rawLen), millis())) return;

  Tnc2Packet d = p;
  d.repeated[idx] = true;
  char out[300];
  if (!tnc2Build(d, out, sizeof(out))) return;

  if (!s_pending.active) {
    s_pending.active = true;
    s_pending.atMs = millis() + 120 + (random(0, 280));
    strlcpy(s_pending.tnc2, out, sizeof(s_pending.tnc2));
  }
}

static void handleLoRa(uint8_t *buf, size_t len, float rssi, float snr) {
  if (len >= 255) return;
  buf[len] = '\0';
  for (size_t i = 0; i < len; ++i)
    if (buf[i] < 0x20 || buf[i] > 0x7E) return;  // APRS is 7-bit text

  ++s_rxCount;
  s_lastRssi = rssi;
  s_lastSnr = snr;
  ledPulse(PIN_LED_BLUE, 25);

  Tnc2Packet p;
  if (!tnc2Parse((const char *)buf, p)) {
    printLine((const char *)buf);
    return;
  }
  strlcpy(s_lastRx, p.src, sizeof(s_lastRx));
  printLine((const char *)buf);

  if (g_cfg.usbMode == USB_KISS) {
    Ax25Frame f;
    if (tnc2ToAx25(p, f)) {
      uint8_t ax[340];
      size_t n = ax25Encode(f, ax, sizeof(ax));
      if (n) kissSendAx25(ax, n);
    }
  }

  maybeDigipeat(p, buf, len);
}

void appHandleHostAx25(const uint8_t *frame, size_t len) {
  Ax25Frame f;
  if (!ax25Decode(frame, len, f)) {
    Serial.println(F("KISS: bad AX.25 frame"));
    return;
  }
  char tnc2[300];
  if (!tnc2FromAx25(f, tnc2, sizeof(tnc2))) return;
  sendTnc2(tnc2, "host");
}

// ------------------------------------------------------------------- setup --

void setup() {
  pinMode(PIN_LED_GREEN, OUTPUT);
  pinMode(PIN_LED_RED, OUTPUT);
  pinMode(PIN_LED_BLUE, OUTPUT);
  pinMode(PIN_BUTTON, INPUT_PULLUP);
  pinMode(PIN_BUZZER, OUTPUT);
  digitalWrite(PIN_BUZZER, LOW);
  digitalWrite(PIN_LED_GREEN, LOW);
  digitalWrite(PIN_LED_RED, LOW);
  digitalWrite(PIN_LED_BLUE, LOW);
  pinMode(PIN_EPD_PWR, OUTPUT);

  Serial.begin(115200);
  delay(150);

  cfgLoad();
  randomSeed(analogRead(PIN_BATTERY) ^ micros());

  Serial.println();
  Serial.printf("%s %s\n", APP_NAME, APP_VERSION);
  Serial.printf("board: LilyGO T-Echo Plus (nRF52840 + SX1262 433 MHz)\n");
  Serial.printf("callsign: %s\n", g_cfg.callsign);

  gpsBegin();
  readBattery();
  uiInit();

  if (!radioBegin(g_cfg)) {
    Serial.printf("RADIO ERROR: %s\n", radioLastErrorText());
    ledPulse(PIN_LED_RED, 500);
  } else {
    Serial.printf("radio ready: %.4f MHz SF%u BW%.1f CR4/%u %d dBm\n",
                  g_cfg.freqHz / 1000000.0, g_cfg.sf, g_cfg.bwKhz, g_cfg.cr, g_cfg.powerDbm);
    ledPulse(PIN_LED_GREEN, 120);
  }

  cliBegin();

  UiState st = { s_txCount, s_rxCount, s_lastRssi, s_lastSnr, "", s_batteryMv, 0 };
  uiDraw(st);
  s_lastDisplayMs = millis();
}

// -------------------------------------------------------------------- loop --

void loop() {
  gpsPoll();

  // radio receive
  uint8_t buf[256];
  size_t len = 0;
  float rssi = 0, snr = 0;
  if (radioPoll(buf, sizeof(buf) - 1, &len, &rssi, &snr) == RADIOLIB_ERR_NONE && len)
    handleLoRa(buf, len, rssi, snr);

  // USB console + KISS
  while (Serial.available()) {
    uint8_t b = (uint8_t)Serial.read();
    if (!kissFeed(b)) cliFeed(b);
  }

  // pending digipeat
  if (s_pending.active && (int32_t)(millis() - s_pending.atMs) >= 0) {
    s_pending.active = false;
    sendTnc2(s_pending.tnc2, "digi");
  }

  // button: short press = beacon, long press (3 s) = BLE OTA mode
  static bool lastBtn = HIGH;
  static uint32_t btnDownMs = 0;
  static bool otaTriggered = false;
  bool btn = digitalRead(PIN_BUTTON);
  if (btn == LOW && lastBtn == HIGH) {
    btnDownMs = millis();
    otaTriggered = false;
  }
  if (btn == LOW && !otaTriggered && (millis() - btnDownMs) >= 3000) {
    otaTriggered = true;
    Serial.println(F("OTA: rebooting into BLE DFU mode..."));
    Serial.flush();
    delay(100);
    NRF_POWER->GPREGRET = 0xA8;
    NVIC_SystemReset();
  }
  if (btn == HIGH && lastBtn == LOW) {
    uint32_t held = millis() - btnDownMs;
    if (!otaTriggered && held >= 50 && held < 1000) {
      s_beaconRequested = true;
      digitalWrite(PIN_BUZZER, HIGH);
      delay(30);
      digitalWrite(PIN_BUZZER, LOW);
    }
  }
  lastBtn = btn;

  // beacon scheduler
  if (g_cfg.mode == MODE_TRACKER) {
    uint32_t interval = (gpsSpeedKmh() >= 5.0f) ? g_cfg.beaconSec : g_cfg.slowSec;
    if (s_beaconRequested || (s_lastTxMs == 0 && gpsHasFix() && millis() > 30000) ||
        (millis() - s_lastTxMs >= interval * 1000UL)) {
      if (gpsHasFix()) appSendPosition();
      else if (s_beaconRequested) Serial.println(F("no GPS fix"));
      s_lastTxMs = millis();
    }
  } else if (s_beaconRequested) {
    if (g_cfg.mode == MODE_OFF) Serial.println(F("TX disabled (mode off)"));
    else appSendPosition();
  }
  s_beaconRequested = false;

  // battery + display
  uint32_t now = millis();
  if (now - s_lastBatteryMs > 30000 || s_lastBatteryMs == 0) {
    s_lastBatteryMs = now;
    readBattery();
  }
  if (now - s_lastDisplayMs > 30000 || s_lastDisplayMs == 0) {
    s_lastDisplayMs = now;
    UiState st = { s_txCount, s_rxCount, s_lastRssi, s_lastSnr, "", s_batteryMv,
                   now / 1000 };
    strlcpy(st.lastRx, s_lastRx, sizeof(st.lastRx));
    uiDraw(st);
  }

  delay(5);
}
