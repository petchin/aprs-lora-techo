// cfg.cpp — JSON configuration in InternalFS.
#include "cfg.h"

#include <Adafruit_LittleFS.h>
#include <InternalFileSystem.h>
#include <ArduinoJson.h>
#include <string.h>
#include <ctype.h>

using namespace Adafruit_LittleFS_Namespace;

Config g_cfg;

static const char *kFile = "/aprs.json";

static void upperCopy(char *dst, const char *src, size_t maxLen) {
  size_t i = 0;
  for (; src[i] && i + 1 < maxLen; ++i) dst[i] = (char)toupper((unsigned char)src[i]);
  dst[i] = '\0';
}

bool cfgSetCallsign(const char *value) {
  char buf[12];
  upperCopy(buf, value, sizeof(buf));
  // base call 1..6 alnum, optional -0..15
  const char *dash = strchr(buf, '-');
  size_t baseLen = dash ? (size_t)(dash - buf) : strlen(buf);
  if (baseLen < 3 || baseLen > 6) return false;
  for (size_t i = 0; i < baseLen; ++i)
    if (!isalnum((unsigned char)buf[i])) return false;
  if (dash) {
    const char *s = dash + 1;
    if (!*s || strlen(s) > 2) return false;
    for (const char *p = s; *p; ++p)
      if (!isdigit((unsigned char)*p)) return false;
    if (atoi(s) > 15) return false;
  }
  strncpy(g_cfg.callsign, buf, sizeof(g_cfg.callsign) - 1);
  g_cfg.callsign[sizeof(g_cfg.callsign) - 1] = '\0';
  return true;
}

bool cfgSetSymbol(const char *value) {
  size_t n = strlen(value);
  if (n == 1) {
    g_cfg.symbol = value[0];
    return true;
  }
  if (n == 2) {
    char t = value[0];
    if (!(t == '/' || t == '\\' || t == '_' || isalnum((unsigned char)t))) return false;
    g_cfg.symbolTable = t;
    g_cfg.symbol = value[1];
    return true;
  }
  return false;
}

void cfgDefaults() {
  g_cfg = Config();
}

void cfgLoad() {
  cfgDefaults();
  InternalFS.begin();
  if (!InternalFS.exists(kFile)) return;

  File f = InternalFS.open(kFile, FILE_O_READ);
  if (!f) return;

  JsonDocument doc;
  DeserializationError err = deserializeJson(doc, f);
  f.close();
  if (err) return;

  if (doc["callsign"].is<const char *>()) cfgSetCallsign(doc["callsign"] | "E23BMY-12");
  if (doc["path"].is<const char *>())
    strlcpy(g_cfg.path, doc["path"] | "WIDE1-1", sizeof(g_cfg.path));
  if (doc["comment"].is<const char *>())
    strlcpy(g_cfg.comment, doc["comment"] | "", sizeof(g_cfg.comment));
  if (doc["symbolTable"].is<const char *>() && doc["symbol"].is<const char *>()) {
    char sym[3] = { doc["symbolTable"].as<const char *>()[0],
                    doc["symbol"].as<const char *>()[0], 0 };
    cfgSetSymbol(sym);
  }
  g_cfg.freqHz       = doc["freqHz"] | g_cfg.freqHz;
  if (g_cfg.freqHz < 430000000UL || g_cfg.freqHz > 928000000UL) g_cfg.freqHz = 433775000UL;
  g_cfg.sf           = doc["sf"] | g_cfg.sf;
  g_cfg.bwKhz        = doc["bwKhz"] | g_cfg.bwKhz;
  g_cfg.cr           = doc["cr"] | g_cfg.cr;
  g_cfg.powerDbm     = doc["powerDbm"] | g_cfg.powerDbm;
  g_cfg.beaconSec    = doc["beaconSec"] | g_cfg.beaconSec;
  g_cfg.slowSec      = doc["slowSec"] | g_cfg.slowSec;
  g_cfg.mode         = doc["mode"] | g_cfg.mode;
  g_cfg.digiEnabled  = doc["digiEnabled"] | g_cfg.digiEnabled;
  g_cfg.usbMode      = doc["usbMode"] | g_cfg.usbMode;

  // clamp radio values
  if (g_cfg.sf < 5 || g_cfg.sf > 12) g_cfg.sf = 12;
  if (g_cfg.cr < 5 || g_cfg.cr > 8) g_cfg.cr = 5;
  if (g_cfg.bwKhz < 7.8f || g_cfg.bwKhz > 500.0f) g_cfg.bwKhz = 125.0f;
  if (g_cfg.powerDbm < 2) g_cfg.powerDbm = 2;
  if (g_cfg.powerDbm > 22) g_cfg.powerDbm = 22;
  if (g_cfg.beaconSec < 15) g_cfg.beaconSec = 15;
  if (g_cfg.slowSec < 30) g_cfg.slowSec = 30;
  if (g_cfg.mode > MODE_OFF) g_cfg.mode = MODE_TRACKER;
  if (g_cfg.usbMode > USB_KISS) g_cfg.usbMode = USB_KISS;
}

void cfgSave() {
  InternalFS.begin();
  InternalFS.remove(kFile);
  File f = InternalFS.open(kFile, FILE_O_WRITE);
  if (!f) return;

  JsonDocument doc;
  doc["callsign"]    = g_cfg.callsign;
  doc["path"]        = g_cfg.path;
  doc["comment"]     = g_cfg.comment;
  char table[2] = { g_cfg.symbolTable, 0 };
  char symbol[2] = { g_cfg.symbol, 0 };
  doc["symbolTable"] = table;
  doc["symbol"]      = symbol;
  doc["freqHz"]      = g_cfg.freqHz;
  doc["sf"]          = g_cfg.sf;
  doc["bwKhz"]       = g_cfg.bwKhz;
  doc["cr"]          = g_cfg.cr;
  doc["powerDbm"]    = g_cfg.powerDbm;
  doc["beaconSec"]   = g_cfg.beaconSec;
  doc["slowSec"]     = g_cfg.slowSec;
  doc["mode"]        = g_cfg.mode;
  doc["digiEnabled"] = g_cfg.digiEnabled;
  doc["usbMode"]     = g_cfg.usbMode;
  serializeJson(doc, f);
  f.close();
}

void cfgPrint(Print &out) {
  out.printf("callsign   %s\n", g_cfg.callsign);
  out.printf("path       %s\n", g_cfg.path);
  out.printf("comment    %s\n", g_cfg.comment);
  out.printf("symbol     %c%c\n", g_cfg.symbolTable, g_cfg.symbol);
  out.printf("freq       %.4f MHz\n", g_cfg.freqHz / 1000000.0);
  out.printf("radio      SF%u BW%.1f CR4/%u %d dBm\n", g_cfg.sf, g_cfg.bwKhz, g_cfg.cr, g_cfg.powerDbm);
  out.printf("beacon     %us moving / %us slow\n", g_cfg.beaconSec, g_cfg.slowSec);
  out.printf("mode       %s\n", g_cfg.mode == MODE_TRACKER ? "tracker" :
                                  g_cfg.mode == MODE_DIGI ? "digi" :
                                  g_cfg.mode == MODE_KISS ? "kiss" : "off");
  out.printf("digi       %s\n", g_cfg.digiEnabled ? "on" : "off");
  out.printf("usb        %s\n", g_cfg.usbMode == USB_KISS ? "kiss" :
                                  g_cfg.usbMode == USB_TNC2 ? "tnc2" : "off");
}
