// cli.h — line-based USB console (APRS-TH commands).
#pragma once

#include <Arduino.h>

void cliBegin();
void cliFeed(uint8_t b);
void cliPrintHelp();
bool appSendPosition();
void appRequestBeacon();
void appPrintStatus(Print &out);
void appReboot();
