// radio.cpp — SX1262 on the T-Echo (TCXO 1.8 V, DIO2 as RF switch).
// LoRa APRS payloads are prefixed with 3C FF 01 on air (as in the ESP32
// reference firmware and the CA2RXU/LoRa-APRS ecosystem).
#include "radio.h"
#include "pins.h"
#include <RadioLib.h>

static Module s_module(PIN_LORA_CS, PIN_LORA_DIO1, PIN_LORA_RST, PIN_LORA_BUSY);
static SX1262 s_radio(&s_module);
static volatile bool s_rxFlag = false;
static bool s_ready = false;
static int16_t s_lastErr = 0;

static const uint8_t kPrefix[3] = { 0x3C, 0xFF, 0x01 };

static void onDio1() { s_rxFlag = true; }

const char *radioLastErrorText() {
  static char buf[48];
  snprintf(buf, sizeof(buf), "RadioLib error %d", (int)s_lastErr);
  return buf;
}

bool radioReady() { return s_ready; }
int16_t radioLastError() { return s_lastErr; }

bool radioBegin(const Config &cfg) {
  SPI.begin();  // variant pins: SCK 19, MISO 23, MOSI 22

  int16_t st = s_radio.begin(cfg.freqHz / 1000000.0f, cfg.bwKhz, cfg.sf, cfg.cr,
                             RADIOLIB_SX126X_SYNC_WORD_PRIVATE, cfg.powerDbm,
                             8, LORA_TCXO_VOLTAGE, false);
  if (st != RADIOLIB_ERR_NONE) {
    // some T-Echo batches have no TCXO: retry as crystal
    st = s_radio.begin(cfg.freqHz / 1000000.0f, cfg.bwKhz, cfg.sf, cfg.cr,
                       RADIOLIB_SX126X_SYNC_WORD_PRIVATE, cfg.powerDbm,
                       8, 0.0f, false);
  }
  if (st != RADIOLIB_ERR_NONE) {
    s_lastErr = st;
    s_ready = false;
    return false;
  }

  s_radio.setDio2AsRfSwitch(true);
  s_radio.setCRC(true);
  s_radio.setCurrentLimit(140.0f);
  s_radio.setRxBoostedGainMode(true);
  s_radio.setDio1Action(onDio1);
  s_radio.startReceive();
  s_ready = true;
  return true;
}

void radioStartRx() {
  if (!s_ready) return;
  s_rxFlag = false;
  s_radio.startReceive();
}

void radioIdle() {
  if (s_ready) s_radio.standby();
}

int16_t radioSendAprs(const char *tnc2, size_t len) {
  if (!s_ready) return RADIOLIB_ERR_UNKNOWN;
  if (len == 0 || len + sizeof(kPrefix) > 255) return RADIOLIB_ERR_PACKET_TOO_LONG;

  uint8_t frame[255];
  memcpy(frame, kPrefix, sizeof(kPrefix));
  memcpy(frame + sizeof(kPrefix), tnc2, len);

  s_rxFlag = false;
  int16_t st = s_radio.transmit(frame, len + sizeof(kPrefix));
  s_radio.startReceive();
  if (st != RADIOLIB_ERR_NONE) s_lastErr = st;
  return st;
}

int16_t radioPoll(uint8_t *out, size_t maxLen, size_t *outLen, float *rssi, float *snr) {
  *outLen = 0;
  if (!s_ready || !s_rxFlag) return RADIOLIB_ERR_NONE;

  s_rxFlag = false;
  size_t len = s_radio.getPacketLength();
  if (len < sizeof(kPrefix) || len > maxLen) {
    s_radio.startReceive();
    return RADIOLIB_ERR_CRC_MISMATCH;
  }
  int16_t st = s_radio.readData(out, len);
  if (rssi) *rssi = s_radio.getRSSI();
  if (snr)  *snr  = s_radio.getSNR();
  s_radio.startReceive();
  if (st != RADIOLIB_ERR_NONE) {
    s_lastErr = st;
    return st;
  }

  // strip the LoRa APRS 3-byte prefix if present
  if (len >= 3 && out[0] == kPrefix[0] && out[1] == kPrefix[1] && out[2] == kPrefix[2]) {
    memmove(out, out + 3, len - 3);
    len -= 3;
  }
  *outLen = len;
  return RADIOLIB_ERR_NONE;
}
