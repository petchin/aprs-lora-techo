// aprs.cpp — TNC2/AX.25 conversion and APRS position encoding.
// LoRa APRS carries a TNC2 line in the LoRa payload; the USB KISS bridge needs
// to translate that to/from real AX.25 frames for aprx/APRSdroid.
#include "aprs.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

static bool copyToken(const char *start, size_t len, char *out, size_t outSize) {
  if (len == 0 || len >= outSize) return false;
  memcpy(out, start, len);
  out[len] = '\0';
  return true;
}

bool tnc2Parse(const char *line, Tnc2Packet &p) {
  p.pathCount = 0;
  p.infoLen = 0;
  const char *gt = strchr(line, '>');
  const char *colon = strrchr(line, ':');
  if (!gt || !colon || colon < gt) return false;

  const char *hdr = gt + 1;
  const char *comma = (const char *)memchr(hdr, ',', (size_t)(colon - hdr));
  const char *dstEnd = comma ? comma : colon;
  if (!copyToken(line, (size_t)(gt - line), p.src, sizeof(p.src))) return false;
  if (!copyToken(hdr, (size_t)(dstEnd - hdr), p.dst, sizeof(p.dst))) return false;

  const char *q = dstEnd;
  while (q < colon) {
    if (*q == ',') {
      ++q;
      const char *e = (const char *)memchr(q, ',', (size_t)(colon - q));
      if (!e) e = colon;
      size_t n = (size_t)(e - q);
      bool rep = false;
      if (n && q[n - 1] == '*') { rep = true; --n; }
      if (p.pathCount >= 8) return false;
      if (!copyToken(q, n, p.path[p.pathCount], sizeof(p.path[0]))) return false;
      p.repeated[p.pathCount] = rep;
      ++p.pathCount;
      q = e;
    } else {
      ++q;
    }
  }

  size_t ilen = (size_t)(line + strlen(line) - (colon + 1));
  if (ilen == 0 || ilen >= sizeof(p.info)) return false;
  memcpy(p.info, colon + 1, ilen);
  p.info[ilen] = '\0';
  p.infoLen = (uint16_t)ilen;
  return true;
}

bool tnc2ToAx25(const Tnc2Packet &p, Ax25Frame &f) {
  strlcpy(f.dst, p.dst, sizeof(f.dst));
  strlcpy(f.src, p.src, sizeof(f.src));
  f.pathCount = p.pathCount;
  for (uint8_t i = 0; i < p.pathCount; ++i) {
    strlcpy(f.path[i], p.path[i], sizeof(f.path[i]));
    f.repeated[i] = p.repeated[i];
  }
  if (p.infoLen > sizeof(f.info)) return false;
  memcpy(f.info, p.info, p.infoLen);
  f.infoLen = p.infoLen;
  return true;
}

size_t tnc2Build(const Tnc2Packet &p, char *out, size_t maxLen) {
  int n = snprintf(out, maxLen, "%s>%s", p.src, p.dst);
  if (n < 0 || (size_t)n >= maxLen) return 0;
  for (uint8_t i = 0; i < p.pathCount; ++i) {
    int m = snprintf(out + n, maxLen - n, ",%s%s", p.path[i], p.repeated[i] ? "*" : "");
    if (m < 0 || (size_t)(n + m) >= maxLen) return 0;
    n += m;
  }
  if ((size_t)n + 1 + p.infoLen >= maxLen) return 0;
  out[n++] = ':';
  memcpy(out + n, p.info, p.infoLen);
  n += p.infoLen;
  out[n] = '\0';
  return (size_t)n;
}

size_t tnc2FromAx25(const Ax25Frame &f, char *out, size_t maxLen) {
  int n = snprintf(out, maxLen, "%s>%s", f.src, f.dst);
  if (n < 0 || (size_t)n >= maxLen) return 0;
  for (uint8_t i = 0; i < f.pathCount; ++i) {
    int m = snprintf(out + n, maxLen - n, ",%s%s", f.path[i], f.repeated[i] ? "*" : "");
    if (m < 0 || (size_t)(n + m) >= maxLen) return 0;
    n += m;
  }
  if ((size_t)n + 1 + f.infoLen >= maxLen) return 0;
  out[n++] = ':';
  memcpy(out + n, f.info, f.infoLen);
  n += f.infoLen;
  out[n] = '\0';
  return (size_t)n;
}

size_t aprsBuildPosition(const Config &cfg, double lat, double lon,
                         float speedKmh, float courseDeg, float altM,
                         char *out, size_t maxLen) {
  if (!isfinite(lat) || !isfinite(lon) || fabs(lat) > 90.0 || fabs(lon) > 180.0)
    return 0;

  char latStr[10], lonStr[11];
  double alat = fabs(lat), alon = fabs(lon);
  int latDeg = (int)alat;
  int lonDeg = (int)alon;
  double latMin = (alat - latDeg) * 60.0;
  double lonMin = (alon - lonDeg) * 60.0;
  snprintf(latStr, sizeof(latStr), "%02d%05.2f%c", latDeg, latMin, lat < 0 ? 'S' : 'N');
  snprintf(lonStr, sizeof(lonStr), "%03d%05.2f%c", lonDeg, lonMin, lon < 0 ? 'W' : 'E');

  char path[48] = "";
  if (cfg.path[0]) snprintf(path, sizeof(path), ",%s", cfg.path);

  int spdKt = (int)lroundf(speedKmh / 1.852f);
  if (spdKt > 999) spdKt = 999;
  if (spdKt < 0) spdKt = 0;
  int crs = (int)lroundf(courseDeg);
  if (crs < 0 || crs > 359) crs = 0;

  bool hasAlt = isfinite(altM) && altM > -100.0f && altM < 20000.0f;
  int altFt = hasAlt ? (int)lroundf(altM * 3.28084f) : 0;

  char safeComment[48];
  size_t ci = 0;
  for (const char *p = cfg.comment; *p && ci + 1 < sizeof(safeComment); ++p) {
    unsigned char c = (unsigned char)*p;
    if (c >= 0x20 && c <= 0x7E) safeComment[ci++] = (char)c;
    else safeComment[ci++] = '?';
  }
  safeComment[ci] = '\0';

  int n = snprintf(out, maxLen, "%s>APRS%s:!%s%c%s%c%03d/%03d%s",
                   cfg.callsign, path, latStr, cfg.symbolTable, lonStr, cfg.symbol,
                   crs, spdKt, safeComment);
  if (n < 0 || (size_t)n >= maxLen) return 0;
  if (hasAlt) {
    int m = snprintf(out + n, maxLen - n, " /A=%06d", altFt);
    if (m < 0 || (size_t)(n + m) >= maxLen) return 0;
    n += m;
  }
  return (size_t)n;
}
