// kiss.cpp — minimal KISS encoder/decoder (data frames only).
#include "kiss.h"

static const uint8_t FEND = 0xC0;
static const uint8_t FESC = 0xDB;
static const uint8_t TFEND = 0xDC;
static const uint8_t TFESC = 0xDD;

static bool s_active = false;
static bool s_escape = false;
static uint8_t s_buf[340];
static size_t s_len = 0;

bool kissActive() { return s_active; }

void kissReset() {
  s_active = false;
  s_escape = false;
  s_len = 0;
}

static void kissWrite(uint8_t b) {
  if (b == FEND) {
    Serial.write(FESC); Serial.write(TFEND);
  } else if (b == FESC) {
    Serial.write(FESC); Serial.write(TFESC);
  } else {
    Serial.write(b);
  }
}

void kissSendAx25(const uint8_t *frame, size_t len) {
  Serial.write(FEND);
  Serial.write((uint8_t)0x00);  // port 0, data frame
  for (size_t i = 0; i < len; ++i) kissWrite(frame[i]);
  Serial.write(FEND);
}

bool kissFeed(uint8_t b) {
  if (!s_active) {
    if (b != FEND) return false;
    s_active = true;
    s_escape = false;
    s_len = 0;
    return true;
  }

  if (b == FEND) {
    if (s_len > 1 && s_buf[0] == 0x00) {
      // s_buf[0] is the KISS command byte; pass the rest as AX.25
      appHandleHostAx25(s_buf + 1, s_len - 1);
    }
    s_active = false;
    s_escape = false;
    s_len = 0;
    return true;
  }

  if (s_escape) {
    s_escape = false;
    b = (b == TFEND) ? FEND : (b == TFESC) ? FESC : b;
  } else if (b == FESC) {
    s_escape = true;
    return true;
  }

  if (s_len < sizeof(s_buf)) s_buf[s_len++] = b;
  return true;
}
