// gps.h — L76K NMEA on Serial1.
#pragma once

#include <Arduino.h>

void gpsBegin();
void gpsPoll();
bool gpsHasFix();
double gpsLat();
double gpsLon();
float gpsSpeedKmh();
float gpsCourseDeg();
float gpsAltM();
uint8_t gpsSats();
float gpsHdop();
uint32_t gpsLastFixMs();
uint32_t gpsChars();
