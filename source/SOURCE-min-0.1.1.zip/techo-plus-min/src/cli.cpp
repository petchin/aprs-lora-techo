// cli.cpp — simple command console on USB serial.
#include "cli.h"
#include "kiss.h"
#include "cfg.h"
#include "gps.h"
#include "radio.h"
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <math.h>
#include <nrf.h>

static char s_line[160];
static size_t s_len = 0;

static void lower(char *s) {
  for (; *s; ++s) *s = (char)tolower((unsigned char)*s);
}

void cliPrintHelp() {
  Serial.println();
  Serial.println(F("APRS-TH T-Echo Plus commands:"));
  Serial.println(F("  info                     show configuration + status"));
  Serial.println(F("  set call <CALL-SSID>     e.g. E23BMY-12"));
  Serial.println(F("  set path <WIDE1-1,...>   empty string = direct"));
  Serial.println(F("  set comment <text>       beacon comment"));
  Serial.println(F("  set symbol </>           1 char, or 2 chars table+symbol"));
  Serial.println(F("  set freq <MHz>           e.g. 433.775 (reboot)"));
  Serial.println(F("  set sf <5-12>            spreading factor (reboot)"));
  Serial.println(F("  set bw <62.5|125|250|500> bandwidth kHz (reboot)"));
  Serial.println(F("  set cr <5-8>             coding rate 4/x (reboot)"));
  Serial.println(F("  set power <2-22>         dBm (reboot)"));
  Serial.println(F("  set interval <sec>       moving beacon interval"));
  Serial.println(F("  set slow <sec>           stationary beacon interval"));
  Serial.println(F("  set mode tracker|digi|kiss|off"));
  Serial.println(F("  set digi on|off          WIDE1-1 digipeater"));
  Serial.println(F("  set usb kiss|tnc2|off    USB bridge output"));
  Serial.println(F("  tx                       send a beacon now"));
  Serial.println(F("  ota                      reboot into BLE OTA/DFU mode"));
  Serial.println(F("  save | reset | reboot | help"));
  Serial.println();
}

static bool parseOnOff(const char *v, bool &out) {
  if (!strcasecmp(v, "on") || !strcasecmp(v, "true") || !strcmp(v, "1")) { out = true; return true; }
  if (!strcasecmp(v, "off") || !strcasecmp(v, "false") || !strcmp(v, "0")) { out = false; return true; }
  return false;
}

static void setCommand(char *args) {
  char *key = strtok(args, " \t");
  if (!key) { Serial.println(F("ERR missing key")); return; }
  char *value = strtok(NULL, "");
  while (value && *value == ' ') ++value;
  if (!value) value = (char *)"";
  lower(key);

  bool reboot = false;

  if (!strcmp(key, "call") || !strcmp(key, "callsign")) {
    if (!cfgSetCallsign(value)) { Serial.println(F("ERR invalid callsign")); return; }
  } else if (!strcmp(key, "path")) {
    if (strlen(value) >= sizeof(g_cfg.path)) { Serial.println(F("ERR path too long")); return; }
    strlcpy(g_cfg.path, value, sizeof(g_cfg.path));
  } else if (!strcmp(key, "comment")) {
    strlcpy(g_cfg.comment, value, sizeof(g_cfg.comment));
  } else if (!strcmp(key, "symbol")) {
    if (!cfgSetSymbol(value)) { Serial.println(F("ERR symbol must be 1 or 2 chars")); return; }
  } else if (!strcmp(key, "freq")) {
    float mhz = atof(value);
    if (mhz < 430.0f || mhz > 928.0f) { Serial.println(F("ERR freq 430..928 MHz")); return; }
    g_cfg.freqHz = (uint32_t)lroundf(mhz * 1000000.0f);
    reboot = true;
  } else if (!strcmp(key, "sf")) {
    int v = atoi(value);
    if (v < 5 || v > 12) { Serial.println(F("ERR sf 5..12")); return; }
    g_cfg.sf = (uint8_t)v; reboot = true;
  } else if (!strcmp(key, "bw")) {
    float v = atof(value);
    if (v != 62.5f && v != 125.0f && v != 250.0f && v != 500.0f) {
      Serial.println(F("ERR bw 62.5|125|250|500")); return;
    }
    g_cfg.bwKhz = v; reboot = true;
  } else if (!strcmp(key, "cr")) {
    int v = atoi(value);
    if (v < 5 || v > 8) { Serial.println(F("ERR cr 5..8")); return; }
    g_cfg.cr = (uint8_t)v; reboot = true;
  } else if (!strcmp(key, "power") || !strcmp(key, "pw")) {
    int v = atoi(value);
    if (v < 2 || v > 22) { Serial.println(F("ERR power 2..22 dBm")); return; }
    g_cfg.powerDbm = (int8_t)v; reboot = true;
  } else if (!strcmp(key, "interval")) {
    int v = atoi(value);
    if (v < 15 || v > 3600) { Serial.println(F("ERR interval 15..3600")); return; }
    g_cfg.beaconSec = (uint16_t)v;
  } else if (!strcmp(key, "slow")) {
    int v = atoi(value);
    if (v < 30 || v > 3600) { Serial.println(F("ERR slow 30..3600")); return; }
    g_cfg.slowSec = (uint16_t)v;
  } else if (!strcmp(key, "mode")) {
    lower(value);
    if (!strcmp(value, "tracker")) g_cfg.mode = MODE_TRACKER;
    else if (!strcmp(value, "digi")) g_cfg.mode = MODE_DIGI;
    else if (!strcmp(value, "kiss")) g_cfg.mode = MODE_KISS;
    else if (!strcmp(value, "off")) g_cfg.mode = MODE_OFF;
    else { Serial.println(F("ERR mode tracker|digi|kiss|off")); return; }
  } else if (!strcmp(key, "digi")) {
    bool on;
    if (!parseOnOff(value, on)) { Serial.println(F("ERR digi on|off")); return; }
    g_cfg.digiEnabled = on;
  } else if (!strcmp(key, "usb")) {
    lower(value);
    if (!strcmp(value, "kiss")) g_cfg.usbMode = USB_KISS;
    else if (!strcmp(value, "tnc2")) g_cfg.usbMode = USB_TNC2;
    else if (!strcmp(value, "off")) g_cfg.usbMode = USB_OFF;
    else { Serial.println(F("ERR usb kiss|tnc2|off")); return; }
    kissReset();
  } else {
    Serial.println(F("ERR unknown key (help)"));
    return;
  }

  cfgSave();
  Serial.println(reboot ? F("OK saved - reboot to apply radio settings") : F("OK saved"));
}

static void handleLine(char *line) {
  while (*line == ' ') ++line;
  size_t n = strlen(line);
  while (n && (line[n - 1] == ' ' || line[n - 1] == '\r')) line[--n] = '\0';
  if (!n) return;

  if (!strncasecmp(line, "AT", 2) && (line[2] == ' ' || line[2] == '\0')) line += 2;
  while (*line == ' ') ++line;

  char *cmd = strtok(line, " \t");
  if (!cmd) return;
  lower(cmd);
  char *args = strtok(NULL, "");

  if (!strcmp(cmd, "help") || !strcmp(cmd, "?")) {
    cliPrintHelp();
  } else if (!strcmp(cmd, "info") || !strcmp(cmd, "status")) {
    appPrintStatus(Serial);
  } else if (!strcmp(cmd, "set")) {
    if (!args) { Serial.println(F("ERR usage: set <key> <value>")); return; }
    setCommand(args);
  } else if (!strcmp(cmd, "ota") || !strcmp(cmd, "dfu")) {
    Serial.println(F("OK rebooting into BLE OTA (DFU) mode"));
    Serial.flush();
    delay(100);
    NRF_POWER->GPREGRET = 0xA8;
    NVIC_SystemReset();
  } else if (!strcmp(cmd, "tx") || !strcmp(cmd, "beacon")) {
    appRequestBeacon();
    Serial.println(F("OK beacon queued"));
  } else if (!strcmp(cmd, "save")) {
    cfgSave();
    Serial.println(F("OK saved"));
  } else if (!strcmp(cmd, "reset")) {
    cfgDefaults();
    cfgSave();
    Serial.println(F("OK defaults restored - reboot"));
  } else if (!strcmp(cmd, "reboot")) {
    Serial.println(F("OK rebooting"));
    Serial.flush();
    delay(50);
    appReboot();
  } else if (!strcmp(cmd, "gps")) {
    Serial.printf("fix=%d sats=%u lat=%.6f lon=%.6f speed=%.1f km/h course=%.0f alt=%.0fm hdop=%.1f chars=%lu\n",
                  gpsHasFix() ? 1 : 0, gpsSats(), gpsLat(), gpsLon(),
                  gpsSpeedKmh(), gpsCourseDeg(), gpsAltM(), gpsHdop(),
                  (unsigned long)gpsChars());
  } else {
    Serial.println(F("ERR unknown command (help)"));
  }
}

void cliBegin() {
  s_len = 0;
  cliPrintHelp();
  appPrintStatus(Serial);
}

void cliFeed(uint8_t b) {
  if (b == '\r' || b == '\n') {
    if (s_len) {
      s_line[s_len] = '\0';
      handleLine(s_line);
      s_len = 0;
    }
    return;
  }
  if (s_len + 1 < sizeof(s_line)) s_line[s_len++] = (char)b;
}
