// epd.cpp — GDEH0154D67 / SSD1681 200x200, 1-bit framebuffer, full refresh.
// Init/refresh sequence from GxEPD2 (GPL-3.0). Bit-banged on purpose: the
// Adafruit nRF52 core's SPI peripheral is claimed by LoRa/Wire on this board.
#include "epd.h"
#include "pins.h"
#include "font5x7.h"
#include <string.h>

static uint8_t s_buf[200 * 25];

static inline void sck(bool v) { digitalWrite(PIN_EPD_SCK, v ? HIGH : LOW); }
static inline void mosi(bool v) { digitalWrite(PIN_EPD_MOSI, v ? HIGH : LOW); }

static void epdWriteByte(uint8_t b) {
  for (int i = 7; i >= 0; --i) {
    mosi(b & (1u << i));
    sck(true);
    delayMicroseconds(1);
    sck(false);
    delayMicroseconds(1);
  }
}

static void epdCmd(uint8_t c) {
  digitalWrite(PIN_EPD_DC, LOW);
  digitalWrite(PIN_EPD_CS, LOW);
  epdWriteByte(c);
  digitalWrite(PIN_EPD_CS, HIGH);
}

static void epdData(uint8_t d) {
  digitalWrite(PIN_EPD_DC, HIGH);
  digitalWrite(PIN_EPD_CS, LOW);
  epdWriteByte(d);
  digitalWrite(PIN_EPD_CS, HIGH);
}

static void epdWaitBusy(uint32_t timeoutMs = 30000) {
  uint32_t start = millis();
  while (digitalRead(PIN_EPD_BUSY) == HIGH) {
    if (millis() - start > timeoutMs) break;
    delay(1);
  }
}

static void epdReset() {
  digitalWrite(PIN_EPD_RST, LOW);
  delay(10);
  digitalWrite(PIN_EPD_RST, HIGH);
  delay(10);
}

static void epdSetWindow() {
  epdCmd(0x11); epdData(0x03);               // x/y increment
  epdCmd(0x44); epdData(0x00); epdData(0x18); // x 0..24
  epdCmd(0x45); epdData(0x00); epdData(0x00);
  epdData(0xC7); epdData(0x00);               // y 0..199
  epdCmd(0x4E); epdData(0x00);
  epdCmd(0x4F); epdData(0x00); epdData(0x00);
}

void epdInit() {
  pinMode(PIN_EPD_SCK, OUTPUT);
  pinMode(PIN_EPD_MOSI, OUTPUT);
  pinMode(PIN_EPD_CS, OUTPUT);
  pinMode(PIN_EPD_DC, OUTPUT);
  pinMode(PIN_EPD_RST, OUTPUT);
  pinMode(PIN_EPD_BUSY, INPUT);
  digitalWrite(PIN_EPD_CS, HIGH);
  digitalWrite(PIN_EPD_PWR, HIGH);   // panel power
  epdReset();
  epdCmd(0x12);                      // soft reset
  delay(10);
  epdCmd(0x01); epdData(0xC7); epdData(0x00); epdData(0x00);
  epdCmd(0x3C); epdData(0x05);       // border
  epdCmd(0x18); epdData(0x80);       // internal temp sensor
  epdSetWindow();
  memset(s_buf, 0x00, sizeof(s_buf));
}

void epdClear() { memset(s_buf, 0x00, sizeof(s_buf)); }

void epdPixel(int16_t x, int16_t y, bool black) {
  if (x < 0 || y < 0 || x >= 200 || y >= 200) return;
  uint8_t mask = (uint8_t)(0x80 >> (x & 7));
  uint8_t &b = s_buf[y * 25 + (x >> 3)];
  if (black) b |= mask; else b &= (uint8_t)~mask;
}

void epdLine(int16_t y) {
  for (int16_t x = 0; x < 200; ++x) epdPixel(x, y, true);
}

int16_t epdTextWidth(const char *text, uint8_t scale) {
  return (int16_t)strlen(text) * 6 * scale;
}

void epdText(int16_t x, int16_t y, const char *text, uint8_t scale, bool black) {
  if (!text) return;
  for (const char *p = text; *p; ++p) {
    const uint8_t *g = EpdFont5x7::glyph(*p);
    for (uint8_t col = 0; col < 5; ++col) {
      uint8_t bits = g[col];
      for (uint8_t row = 0; row < 7; ++row) {
        if (!(bits & (1u << row))) continue;
        for (uint8_t dy = 0; dy < scale; ++dy)
          for (uint8_t dx = 0; dx < scale; ++dx)
            epdPixel(x + col * scale + dx, y + row * scale + dy, black);
      }
    }
    x += 6 * scale;
    if (x > 200) break;
  }
}

void epdRefresh() {
  epdSetWindow();
  epdCmd(0x24);
  digitalWrite(PIN_EPD_DC, HIGH);
  digitalWrite(PIN_EPD_CS, LOW);
  for (size_t i = 0; i < sizeof(s_buf); ++i) epdWriteByte(s_buf[i]);
  digitalWrite(PIN_EPD_CS, HIGH);
  epdCmd(0x22); epdData(0xF7);   // full update
  epdCmd(0x20);
  epdWaitBusy(30000);
}

void epdSleep() {
  epdCmd(0x10); epdData(0x01);   // deep sleep
  digitalWrite(PIN_EPD_PWR, LOW);
}
